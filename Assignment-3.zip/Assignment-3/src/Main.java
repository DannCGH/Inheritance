public class Main {
    public static void main(String[] args){
        Doctor Bob = new Doctor("Bob", "Wed Dec 31 19:00:12 EST 1969",
                34000.0, "Pediatrist", 10.5);
        System.out.println(Bob.toString());

        Doctor Susan = new Doctor("Susan", "Wed Dec 31 19:04:14 EST 1969",
                450000.0, "Surgeon", 150.5);
        System.out.println(Susan.toString());

        Doctor Lilly = new Doctor("Lilly", "Wed Dec 31 19:04:14 EST 1969",
                290000.0, "Kidney", 95.5);
        System.out.println(Lilly.toString());

        System.out.println();

        System.out.println("*Patient's Information*");
        Patient Fred = new Patient("Fred", Bob);
        System.out.println(Fred.toString());

        Patient Sally = new Patient("Sally", Susan);
        System.out.println(Sally.toString());

        Patient John = new Patient("John", Lilly);
        System.out.println(John.toString());

        System.out.println();

        System.out.println("*Billings's Information*");
        Billing billing1 = new Billing(Fred, Bob, 21.0);
        System.out.println(billing1.toString());
        Billing billing2 = new Billing(Sally, Susan, 150.5);
        System.out.println(billing2.toString());
        Billing billing3 = new Billing(John, Lilly, 170.0);
        System.out.println(billing3.toString());

        System.out.println();

        System.out.println("The total income from billing records is: " +
                (billing1.getAmountDue() + billing2.getAmountDue() + billing3.getAmountDue()));

    }
}
