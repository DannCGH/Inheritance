public class SalariedEmployee extends Employee {
    private double salary;

    public SalariedEmployee(){
        super();
        this.salary = 0.0;
    }
    public SalariedEmployee(String name, String hireDate, double salary){
        super(name, hireDate);
        setSalary(salary);
    }

    public SalariedEmployee(SalariedEmployee object){
        super(object);
        setSalary(object.getSalary());
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String toString(){
        return "";
    }
    public boolean equals(SalariedEmployee other){
        return super.equals(other) && getSalary() == other.getSalary();
    }
}
