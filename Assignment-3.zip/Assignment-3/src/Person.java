import java.util.Objects;

public class Person {
    private String name;

    public Person(){
        this("No Name Yet");
    }
    public Person(String name){
        setName(name);
    }
    public Person(Person object){
        setName(object.getName());
    }

    public String getName() {
        return name;
    }

    public String setName(String name) {
        this.name = name;
        return name;
    }

    public String toString(){
        return "The name is: " + getName();
    }
    public boolean equals(Person other){
        return (getName().equals(other.getName()));
    }

}