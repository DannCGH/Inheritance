public class Patient extends Person {

    private Doctor primaryPhysician;

    Patient(String name, Doctor primaryPhysician){
        super(name);
        setPrimaryPhysician(primaryPhysician);
    }

    public Doctor getPrimaryPhysician() {
        return primaryPhysician;
    }

    public void setPrimaryPhysician(Doctor primaryPhysician) {
        this.primaryPhysician = primaryPhysician;
    }

    public String toString(){
        return super.toString() + ", Primary doctor is: " + getPrimaryPhysician().getName();
    }
    public boolean equals(Patient other){
        return super.equals(other) && getPrimaryPhysician().equals(other.getPrimaryPhysician());
    }
}
