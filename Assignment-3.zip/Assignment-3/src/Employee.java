public class Employee extends Person {
    private String hireDate;

    public Employee(){
        super();
        this.hireDate = "Mon Jan 1";
    }
    public Employee(String name, String hireDate){
        super(name);
        setHireDate(hireDate);
    }

    public Employee(Employee object){
        super(object);
        setHireDate(object.getHireDate());
    }

    public String getHireDate() {
        return hireDate;
    }

    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    public String toString(){
        return "";
    }
    public boolean equals(Employee other){
        return super.equals(other) && getHireDate().equals(other.getHireDate());
    }
}
