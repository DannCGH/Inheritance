public class Doctor extends SalariedEmployee {
    private String specialty;
    private double fee;

    public Doctor(String name, String hireDate, double salary, String specialty, double fee){
        super(name, hireDate, salary);
        setSpecialty(specialty);
        setFee(fee);
    }

    public String getSpecialty() {
        return specialty;
    }

    public double getFee() {
        return fee;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public String toString(){
        return "The doctor " + getName() + " was hired on " + getHireDate() + " at Salary " +
                getSalary() + ".\nTheir specialty is " + getSpecialty() + " and visit fee is $" +
                getFee() + ".";
    }
    public boolean equals(Doctor other){
        return super.equals(other) && getSpecialty().equals(other.getSpecialty()) && getFee() == other.getFee();
    }
}
