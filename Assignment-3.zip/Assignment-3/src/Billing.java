public class Billing {

    Patient patient;
    Doctor primaryPhysician;
    private double amountDue;

    Billing(Patient patient, Doctor primaryPhysician, double amountDue){
        setPatient(patient);
        setPrimaryPhysician(primaryPhysician);
        setAmountDue(amountDue);
    }

    public Patient getPatient() {
        return patient;
    }

    public Doctor getPrimaryPhysician() {
        return primaryPhysician;
    }

    public double getAmountDue() {
        return amountDue;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setPrimaryPhysician(Doctor primaryPhysician) {
        this.primaryPhysician = primaryPhysician;
    }

    public void setAmountDue(double amountDue) {
        this.amountDue = amountDue;
    }

    public String toString(){
        return "Patient: " + getPatient().getName() +
                "\nDoctor: " + getPrimaryPhysician().getName() +
                "\nAmount Due: $" + getAmountDue();
    }
    public boolean equals(Billing other){
        return getPatient().equals(other.getPatient()) &&
                getPrimaryPhysician().equals(other.getPrimaryPhysician()) &&
                getAmountDue() == other.getAmountDue();
    }
}
